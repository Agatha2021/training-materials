# -*- coding: utf-8 -*-
"""
课件 ↔ 讲师手册 一致性核对：逐页查覆盖，输出报告（可选 docx 核对表）。
用法：
    python -X utf8 check_consistency.py 课件.pptx 内容.json [--docx 核对表.docx]

判定规则：
  ✓ 该页在教学过程的某个环节里被页码引用
  ○ 封面／课程概要／过渡页，本就不该单独成环节（覆盖由所属模块承担）
  × 内容页、练习页、总结页没被任何环节引用 —— 讲课时会成为"飞页"，必须处理
  ⚠ 页码被引用，但课件该页内容像占位（含"补充/待补/另有一页"字样）
另外核算：引用页码是否超出课件总页数。
"""
import json
import re
import sys
import zipfile
from xml.etree import ElementTree as ET

sys.path.insert(0, __file__.rsplit('\\', 1)[0].rsplit('/', 1)[0] + '/scripts')
from ppt_outline import outline, KIND_CN  # noqa: E402

A = '{http://schemas.openxmlformats.org/drawingml/2006/main}'
REF = re.compile(r'第([0-9、，,\-—－~至]+)页')
PLACEHOLDER = ('补充', '待补', '另有一页', '待定', '待完善')


def expand(token):
    """把 '5—13' / '23、24' 展开成页码列表"""
    pages = set()
    for part in re.split(r'[、，,]', token):
        part = part.strip()
        if not part:
            continue
        rng = re.split(r'[—－\-~至]', part)
        if len(rng) == 2 and rng[0].isdigit() and rng[1].isdigit():
            pages.update(range(int(rng[0]), int(rng[1]) + 1))
        elif part.isdigit():
            pages.add(int(part))
    return pages


def step_pages(step):
    blob = ' '.join([step.get('name', ''), step.get('tools', ''),
                     step.get('points', '')] + step.get('acts', []))
    pages = set()
    for m in REF.finditer(blob):
        pages |= expand(m.group(1))
    return pages


def analyse(pptx, data):
    pages = outline(pptx)
    total = len(pages)
    steps = data['process']['steps']
    cover = [(s['name'], step_pages(s)) for s in steps]

    rows = []
    problems = []
    for p in pages:
        pg = p['page']
        owner = next((name for name, ps in cover if pg in ps), '')
        blob = ' '.join(p['lines'])
        placeholder = any(k in blob for k in PLACEHOLDER)
        if owner:
            result = '⚠ 待补内容' if placeholder else '✓ 已覆盖'
            if placeholder:
                problems.append('第%d页有问题但仍是占位页：%s' % (pg, p['title'][:30]))
        elif p['kind'] in ('cover', 'overview', 'transition'):
            result = '○ 不单列'
        else:
            result = '× 未覆盖'
            problems.append('第%d页（%s）没有环节引用：%s' %
                            (pg, KIND_CN[p['kind']], p['title'][:30]))
        rows.append([str(pg), KIND_CN[p['kind']], p['title'][:34], owner or '—', result])

    over = [(name, sorted(x for x in ps if x > total or x < 1))
            for name, ps in cover if any(x > total or x < 1 for x in ps)]
    for name, bad in over:
        problems.append('环节“%s”引用了不存在的页码：%s' % (name, bad))

    covered = sum(1 for r in rows if r[4].startswith('✓'))
    must = sum(1 for r in rows if r[4].startswith('×'))
    return dict(total=total, rows=rows, problems=problems,
                covered=covered, must=must, pages=pages)


# ---------------- docx 输出 ----------------
def write_docx(res, out, title, lines_extra):
    from docx import Document
    from docx.shared import Cm, Pt
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement

    d = Document()
    s = d.sections[0]
    s.page_width, s.page_height = Cm(21.0), Cm(29.7)
    s.top_margin, s.bottom_margin = Cm(2.2), Cm(2.0)
    s.left_margin, s.right_margin = Cm(2.4), Cm(2.4)
    st = d.styles['Normal']
    st.font.name = '宋体'
    st.font.size = Pt(11)
    st._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')

    def para(text, size=11, bold=False, name='宋体', align=WD_ALIGN_PARAGRAPH.JUSTIFY,
             indent=False, sb=0, sa=0):
        p = d.add_paragraph()
        p.alignment = align
        pf = p.paragraph_format
        pf.space_before = Pt(sb)
        pf.space_after = Pt(sa)
        pf.line_spacing = 1.35
        pf.first_line_indent = Pt(size * 2) if indent else Pt(0)
        r = p.add_run(text)
        r.font.name = name
        r._element.rPr.rFonts.set(qn('w:eastAsia'), name)
        r.font.size = Pt(size)
        r.bold = bold

    para(title, size=17, bold=True, name='黑体', align=WD_ALIGN_PARAGRAPH.CENTER, sa=6)
    para('课件共 %d 页｜已被教学过程覆盖 %d 页｜须处理 %d 页' %
         (res['total'], res['covered'], res['must']),
         size=10.5, name='楷体', align=WD_ALIGN_PARAGRAPH.CENTER, sa=10)

    t = d.add_table(rows=1 + len(res['rows']), cols=5)
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    tblPr = t._tbl.tblPr
    lay = OxmlElement('w:tblLayout')
    lay.set(qn('w:type'), 'fixed')
    tblPr.append(lay)
    b = OxmlElement('w:tblBorders')
    for e in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        x = OxmlElement('w:' + e)
        x.set(qn('w:val'), 'single')
        x.set(qn('w:sz'), '6')
        x.set(qn('w:color'), '595959')
        b.append(x)
    tblPr.append(b)
    widths = [Cm(1.2), Cm(2.2), Cm(7.4), Cm(3.6), Cm(2.2)]
    for i, w in enumerate(widths):
        t.columns[i].width = w

    def fill(cell, text, size=8.5, bold=False, center=False):
        cell.text = ''
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER if center else WD_ALIGN_PARAGRAPH.LEFT
        p.paragraph_format.line_spacing = 1.1
        p.paragraph_format.space_after = Pt(0)
        r = p.add_run(text)
        r.font.name = '宋体'
        r._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
        r.font.size = Pt(size)
        r.bold = bold

    for i, h in enumerate(['页码', '页型', '课件首行', '覆盖环节', '结果']):
        c = t.rows[0].cells[i]
        fill(c, h, bold=True, center=True)
        tcPr = c._tc.get_or_add_tcPr()
        shd = OxmlElement('w:shd')
        shd.set(qn('w:val'), 'clear')
        shd.set(qn('w:fill'), 'DCE6F1')
        tcPr.append(shd)
    for ri, row in enumerate(res['rows'], start=1):
        for ci, v in enumerate(row):
            fill(t.rows[ri].cells[ci], v, center=(ci in (0, 1, 4)))

    if res['problems']:
        para('需处理项', size=12, bold=True, name='黑体', sb=12, sa=4)
        for i, p_ in enumerate(res['problems'], start=1):
            para('%d.%s' % (i, p_), size=10.5)
    if lines_extra:
        for head, items in lines_extra:
            para(head, size=12, bold=True, name='黑体', sb=10, sa=4)
            for i, it in enumerate(items, start=1):
                para('%d.%s' % (i, it), size=10.5)

    d.save(out)
    return out


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    pptx, js = sys.argv[1], sys.argv[2]
    with open(js, encoding='utf-8') as f:
        data = json.load(f)
    res = analyse(pptx, data)
    print('共 %d 页｜覆盖 %d 页｜须处理 %d 页' %
          (res['total'], res['covered'], res['must']))
    for r in res['rows']:
        print('%3s  %-5s %-5s %s' % (r[0], r[4], r[1], r[2][:26]))
    if res['problems']:
        print('\n需处理：')
        for p in res['problems']:
            print(' -', p)
    if '--docx' in sys.argv:
        i = sys.argv.index('--docx')
        out = sys.argv[i + 1] if len(sys.argv) > i + 1 else '核对表.docx'
        write_docx(res, out, '课件与讲师手册一致性核对表', [])
        print('saved:', out)
    sys.exit(1 if res['must'] else 0)


if __name__ == '__main__':
    main()
