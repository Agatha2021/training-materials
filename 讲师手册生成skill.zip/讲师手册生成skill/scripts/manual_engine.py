# -*- coding: utf-8 -*-
"""
讲师手册版式引擎：内容 JSON -> 规范 docx
用法：
    python -X utf8 manual_engine.py 内容.json [输出.docx]
不传输出路径时，输出到 JSON 同目录 <JSON文件名>.docx

JSON 结构见 templates/换牌首检三步守质.json。
版式（封面、三大部分、四列五行教学过程表、页脚页码）由本脚本固定，
内容只负责"写什么"，不再管"怎么排"。
"""
import json
import os
import sys

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

# ---------------- 基础工具 ----------------

def set_run(run, name='宋体', size=12, bold=False):
    run.font.name = name
    run._element.rPr.rFonts.set(qn('w:eastAsia'), name)
    run.font.size = Pt(size)
    run.bold = bold


def shade(cell, hexfill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:color'), 'auto')
    shd.set(qn('w:fill'), hexfill)
    tcPr.append(shd)


def borders(table, sz=6, color='595959'):
    b = OxmlElement('w:tblBorders')
    for edge in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        e = OxmlElement('w:' + edge)
        e.set(qn('w:val'), 'single')
        e.set(qn('w:sz'), str(sz))
        e.set(qn('w:space'), '0')
        e.set(qn('w:color'), color)
        b.append(e)
    table._tbl.tblPr.append(b)


def cell_margins(table, top=60, bottom=60, left=90, right=90):
    mar = OxmlElement('w:tblCellMar')
    for k, v in (('top', top), ('left', left), ('bottom', bottom), ('right', right)):
        e = OxmlElement('w:' + k)
        e.set(qn('w:w'), str(v))
        e.set(qn('w:type'), 'dxa')
        mar.append(e)
    table._tbl.tblPr.append(mar)


def fixed_layout(table, widths):
    lay = OxmlElement('w:tblLayout')
    lay.set(qn('w:type'), 'fixed')
    table._tbl.tblPr.append(lay)
    tw = OxmlElement('w:tblW')
    tw.set(qn('w:w'), str(sum(w.twips for w in widths)))
    tw.set(qn('w:type'), 'dxa')
    table._tbl.tblPr.append(tw)
    for i, w in enumerate(widths):
        table.columns[i].width = w


def no_split(table):
    for row in table.rows:
        trPr = row._tr.get_or_add_trPr()
        e = OxmlElement('w:cantSplit')
        e.set(qn('w:val'), 'true')
        trPr.append(e)


def cell_text(cell, text, size=9.5, bold=False, name='宋体',
              align=WD_ALIGN_PARAGRAPH.LEFT, line=1.2):
    cell.text = ''
    p = cell.paragraphs[0]
    p.alignment = align
    pf = p.paragraph_format
    pf.line_spacing = line
    pf.space_before = Pt(0)
    pf.space_after = Pt(0)
    r = p.add_run(text)
    set_run(r, name, size, bold)


def add_page_number(section):
    p = section.footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r1 = p.add_run('— ')
    set_run(r1, '宋体', 9)
    fld = OxmlElement('w:fldSimple')
    fld.set(qn('w:instr'), 'PAGE')
    r = OxmlElement('w:r')
    rPr = OxmlElement('w:rPr')
    sz = OxmlElement('w:sz')
    sz.set(qn('w:val'), '18')
    rPr.append(sz)
    r.append(rPr)
    t = OxmlElement('w:t')
    t.text = '1'
    r.append(t)
    fld.append(r)
    p._p.append(fld)
    r2 = p.add_run(' —')
    set_run(r2, '宋体', 9)


# ---------------- 渲染 ----------------

class ManualBuilder:
    def __init__(self, data):
        self.d = data
        self.doc = Document()
        self._page()
        self._style()

    def _page(self):
        s = self.doc.sections[0]
        s.page_width, s.page_height = Cm(21.0), Cm(29.7)
        s.top_margin, s.bottom_margin = Cm(2.4), Cm(2.2)
        s.left_margin, s.right_margin = Cm(2.7), Cm(2.7)
        add_page_number(s)

    def _style(self):
        st = self.doc.styles['Normal']
        st.font.name = '宋体'
        st.font.size = Pt(12)
        st._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
        pf = st.paragraph_format
        pf.line_spacing = 1.5
        pf.space_before = Pt(0)
        pf.space_after = Pt(0)

    # 段落
    def p(self, text='', size=12, bold=False, name='宋体', indent=True,
          align=WD_ALIGN_PARAGRAPH.JUSTIFY, sb=0, sa=0, line=1.5, left=None):
        pa = self.doc.add_paragraph()
        pa.alignment = align
        pf = pa.paragraph_format
        pf.line_spacing = line
        pf.space_before = Pt(sb)
        pf.space_after = Pt(sa)
        pf.first_line_indent = Pt(size * 2) if indent else Pt(0)
        if left is not None:
            pf.left_indent = Pt(left)
        if text:
            r = pa.add_run(text)
            set_run(r, name, size, bold)
        return pa

    def h1(self, t):
        self.p(t, size=15, bold=True, name='黑体', indent=False,
               align=WD_ALIGN_PARAGRAPH.LEFT, sb=14, sa=8, line=1.4)

    def h2(self, t):
        self.p(t, size=13, bold=True, name='黑体', indent=False,
               align=WD_ALIGN_PARAGRAPH.LEFT, sb=8, sa=4, line=1.4)

    # 封面
    def cover(self):
        c = self.d['cover']
        for _ in range(3):
            self.p('', indent=False)
        self.p(c['title'], size=30, bold=True, name='微软雅黑', indent=False,
               align=WD_ALIGN_PARAGRAPH.CENTER, sa=6)
        self.p(c.get('subtitle', ''), size=30, bold=True, name='微软雅黑', indent=False,
               align=WD_ALIGN_PARAGRAPH.CENTER, sa=10)
        self.p(c.get('tagline', ''), size=14, name='楷体', indent=False,
               align=WD_ALIGN_PARAGRAPH.CENTER, sa=40)
        for ch in c.get('vertical', '讲师手册'):
            self.p(ch, size=40, bold=True, name='黑体', indent=False,
                   align=WD_ALIGN_PARAGRAPH.CENTER, line=1.0, sa=4)
        for _ in range(3):
            self.p('', indent=False)
        self.p(c.get('code', '参赛号：______'), size=14, name='楷体', indent=False,
               align=WD_ALIGN_PARAGRAPH.CENTER, sa=6)
        self.p(c.get('date', ''), size=12, name='楷体', indent=False,
               align=WD_ALIGN_PARAGRAPH.CENTER)
        self.doc.add_page_break()

    # 一、课程概述
    def overview(self):
        o = self.d['overview']
        self.h1('一、课程概述')
        self.h2('（一）课程开发背景')
        for para in o['background']:
            self.p(para)
        self.h2('（二）课程目标')
        for label, text in o['objectives']:
            self.p(label + text)
        self.h2('（三）培训对象')
        self.p(o['audience'])
        self.h2('（四）课程时长')
        self.p(o['minutes'])
        self.h2('（五）培训人数')
        self.p(o['people'])
        self.h2('（六）场地及设施要求')
        for para in o['venue']:
            self.p(para)

    # 二、教学内容
    def content(self):
        c = self.d['content']
        self.h1('二、教学内容')
        self.h2('（一）课程内容框架')
        if c.get('difficulty'):
            self.p(c['difficulty'])
        for mod in c['modules']:
            self.p(mod['name'], bold=True, indent=False, sb=6)
            for item in mod['items']:
                head = item.split('  ')[0]
                pa = self.p(item, indent=False)
                pa.paragraph_format.left_indent = Pt(24 * head.count('.'))
        if c.get('framework_note'):
            self.p(c['framework_note'], size=10.5, name='楷体', indent=False, sb=4)

        self.h2('（二）重点与难点')
        for blk in (c.get('keypoint'), c.get('hardpoint')):
            if not blk:
                continue
            self.p(blk['title'], bold=True, indent=False, sb=6)
            for para in blk['paras']:
                self.p(para)

        self.h2('（三）教学亮点')
        for h in c['highlights']:
            self.p(h)

    # 三、教学过程安排
    def process(self):
        pr = self.d['process']
        self.h1('三、教学过程安排')
        self.h2('（一）课前准备')
        self.p(pr['prepare']['teacher'])
        self.p(pr['prepare']['student'])

        self.h2('（二）授课计划')
        plan = pr['plan']
        t = self.doc.add_table(rows=1 + len(plan), cols=3)
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        t.autofit = False
        borders(t)
        cell_margins(t)
        widths = [Cm(1.6), Cm(10.4), Cm(3.2)]
        fixed_layout(t, widths)
        no_split(t)
        for i, h in enumerate(['序号', '过程安排', '时长']):
            cell = t.rows[0].cells[i]
            cell_text(cell, h, size=10.5, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER)
            shade(cell, 'DCE6F1')
        for ri, row in enumerate(plan, start=1):
            for ci, val in enumerate(row):
                cell = t.rows[ri].cells[ci]
                al = WD_ALIGN_PARAGRAPH.CENTER if ci != 1 else WD_ALIGN_PARAGRAPH.LEFT
                cell_text(cell, val, size=10.5, align=al)
        if pr.get('plan_note'):
            self.p(pr['plan_note'], size=9, name='楷体', indent=False,
                   align=WD_ALIGN_PARAGRAPH.RIGHT, sb=3)

        self.h2('（三）教学过程')
        if pr.get('steps_note'):
            self.p(pr['steps_note'], size=10.5, name='楷体')
        self.step_tables(pr['steps'])
        if pr.get('footnote'):
            self.p(pr['footnote'], size=9, name='楷体', indent=False, sb=10)

    def step_tables(self, steps):
        widths = [Cm(8.0), Cm(2.6), Cm(1.8), Cm(2.8)]
        for st in steps:
            tbl = self.doc.add_table(rows=5, cols=4)
            tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
            tbl.autofit = False
            borders(tbl)
            cell_margins(tbl, top=50, bottom=50, left=80, right=80)
            fixed_layout(tbl, widths)
            no_split(tbl)

            r0 = tbl.rows[0]
            c0 = r0.cells[0].merge(r0.cells[1]).merge(r0.cells[2]).merge(r0.cells[3])
            cell_text(c0, st['name'], size=10.5, bold=True, name='黑体')
            shade(c0, 'DCE6F1')

            r1 = tbl.rows[1]
            c1 = r1.cells[0].merge(r1.cells[1]).merge(r1.cells[2]).merge(r1.cells[3])
            cell_text(c1, '单元目标：' + st['goal'], size=9.5)
            shade(c1, 'F4F7FB')

            for i, h in enumerate(['内容要点', '教学方法', '教学时长', '教具准备']):
                cell = tbl.rows[2].cells[i]
                cell_text(cell, h, size=9.5, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER)
                shade(cell, 'EFEFEF')

            vals = [st['points'], st['method'], st['time'], st['tools']]
            for i, v in enumerate(vals):
                cell = tbl.rows[3].cells[i]
                al = WD_ALIGN_PARAGRAPH.JUSTIFY if i == 0 else WD_ALIGN_PARAGRAPH.CENTER
                cell_text(cell, v, size=9.5, align=al)

            r4 = tbl.rows[4]
            c4 = r4.cells[0].merge(r4.cells[1]).merge(r4.cells[2]).merge(r4.cells[3])
            c4.text = ''
            p = c4.paragraphs[0]
            p.paragraph_format.line_spacing = 1.2
            p.paragraph_format.space_after = Pt(3)
            r = p.add_run('教学活动组织：')
            set_run(r, '宋体', 9.5, True)
            for act in st['acts']:
                pp = c4.add_paragraph()
                pp.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
                pp.paragraph_format.line_spacing = 1.2
                pp.paragraph_format.space_after = Pt(3)
                rr = pp.add_run(act)
                set_run(rr, '宋体', 9.5)

    def build(self, path):
        self.cover()
        self.overview()
        self.content()
        self.process()
        self.doc.save(path)


# ---------------- 时长核算 ----------------

def parse_minutes(text):
    """从“1.5分钟”“2分钟”里取出数字"""
    s = str(text).replace('分钟', '').strip()
    try:
        return float(s)
    except ValueError:
        return None


def audit(data):
    """三处时长核对：概述总时长 = 授课计划各行之和 = 各环节表之和"""
    msgs = []
    total = parse_minutes(data['overview']['minutes'].split('：')[-1])
    plan_sum = sum(parse_minutes(r[2]) or 0 for r in data['process']['plan'])
    step_sum = sum(parse_minutes(s['time']) or 0 for s in data['process']['steps'])
    msgs.append('总时长 %s｜授课计划合计 %s｜环节表合计 %s' %
                (total, plan_sum, step_sum))
    ok = True
    if total is None:
        msgs.append('✗ 无法识别总时长')
        ok = False
    else:
        if abs(plan_sum - total) > 1e-6:
            msgs.append('✗ 授课计划合计 %s ≠ 总时长 %s' % (plan_sum, total))
            ok = False
        if abs(step_sum - total) > 1e-6:
            msgs.append('✗ 环节表合计 %s ≠ 总时长 %s' % (step_sum, total))
            ok = False
    if len(data['process']['plan']) != len(data['process']['steps']):
        msgs.append('✗ 授课计划 %d 行 ≠ 环节表 %d 张' %
                    (len(data['process']['plan']), len(data['process']['steps'])))
        ok = False
    if ok:
        msgs.append('✓ 三处时长一致')
    return ok, msgs


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    src = sys.argv[1]
    with open(src, encoding='utf-8') as f:
        data = json.load(f)
    ok, msgs = audit(data)
    for m in msgs:
        print(m)
    out = sys.argv[2] if len(sys.argv) > 2 else os.path.splitext(src)[0] + '.docx'
    ManualBuilder(data).build(out)
    print('saved:', out)
    if not ok:
        print('注意：时长核算未通过，文档已生成但需修正 JSON。')
        sys.exit(2)


if __name__ == '__main__':
    main()
