#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""讲师手册成稿自检（离线、只读）。

用法:
    python check_manual.py <成稿文件.md 或 .txt>

检查项（对应评分标准里的"可量化"部分）:
    1. 总时长 vs 授课计划各行之合
    2. 内容框架 一级/二级/三级 数量（2-3 / 5-8 / 12-20）
    3. 背景三段字数（约120/140/140）、培训对象字数（100-160）
    4. 目标：以"学员能够"开头 + 禁用词（掌握/精通/深入了解）
    5. 技能目标是否含条件与标准（ABCD 的 C 与 D）
    6. 内容框架里是否混入教学活动名称
    7. 内容要点里是否出现讲师/学员动作
    8. 教学活动组织每条是否"四字动宾短语＋冒号"起句

仅作提示，不替代人工判断；退出码 0=无阻断问题，1=有 Error。
"""

import re
import sys

ERROR, WARN, OK = "ERROR", "WARN", "OK"
issues = []


def add(level, item, detail):
    issues.append((level, item, detail))


def load(path):
    with open(path, encoding="utf-8", errors="ignore") as f:
        return f.read()


def region(text, start_pat, end_pats):
    """截取 start_pat 之后、任一 end_pat 之前的文本"""
    m = re.search(start_pat, text)
    if not m:
        return ""
    rest = text[m.end():]
    cut = len(rest)
    for p in end_pats:
        m2 = re.search(p, rest)
        if m2 and m2.start() < cut:
            cut = m2.start()
    return rest[:cut]


def cn_len(s):
    return len(re.sub(r"\s", "", s))


def main():
    if len(sys.argv) < 2:
        print("用法: python check_manual.py <成稿文件>")
        return 2
    text = load(sys.argv[1])

    # ---------- 1. 时长核算 ----------
    total_m = re.search(r"课程时长[：:]\s*([0-9.]+)\s*分钟", text)
    total = float(total_m.group(1)) if total_m else None
    plan = region(text, r"（二）授课计划|\(二\)授课计划|二、授课计划", [r"（三）教学过程|\(三\)教学过程|三、教学过程"])
    plan_sum = 0.0
    plan_rows = 0
    for line in plan.splitlines():
        if line.strip().startswith("|") and "分钟" in line:
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            if not cells:
                continue
            last = cells[-1]
            mm = re.fullmatch(r"([0-9.]+)\s*分钟", last)
            if mm:
                plan_sum += float(mm.group(1))
                plan_rows += 1
    if total is None:
        add(WARN, "总时长", "未找到“课程时长：N分钟”，无法核算")
    elif plan_rows == 0:
        add(WARN, "总时长", "未解析到授课计划表，请人工核算各环节时长之和")
    elif abs(plan_sum - total) > 1e-6:
        add(ERROR, "总时长", "课程概述 %.1f 分钟 ≠ 授课计划合计 %.1f 分钟" % (total, plan_sum))
    else:
        add(OK, "总时长", "合计 %.1f 分钟，与课程概述一致（%d 行）" % (plan_sum, plan_rows))

    # ---------- 2. 内容框架层级数量 ----------
    fw = region(text, r"（一）课程内容框架|\(一\)课程内容框架", [r"（二）重点与难点|\(二\)重点与难点"])
    if not fw.strip():
        add(WARN, "内容框架", "未定位到“（一）课程内容框架”")
    else:
        l1 = len(re.findall(r"^\s*[-*>#\s]*模块\s*\d", fw, re.M))
        l2 = len(re.findall(r"^\s*\d+\.\d+\s", fw, re.M))
        l3 = len(re.findall(r"^\s*\d+\.\d+\.\d+\s", fw, re.M))
        if not (2 <= l1 <= 3):
            add(ERROR if l1 else WARN, "内容框架·一级", "一级模块 %d 个（要求 2-3）" % l1)
        if not (5 <= l2 <= 8):
            add(WARN, "内容框架·二级", "二级知识点 %d 个（要求 5-8）" % l2)
        if not (12 <= l3 <= 20):
            add(WARN, "内容框架·三级", "三级要素 %d 个（要求 12-20）" % l3)
        if 2 <= l1 <= 3 and 5 <= l2 <= 8 and 12 <= l3 <= 20:
            add(OK, "内容框架·数量", "%d / %d / %d，符合 2-3 / 5-8 / 12-20" % (l1, l2, l3))

        bad = re.findall(r"(案例导入|小组讨论|讲师示范|角色演练|学员汇报|教师点评|分组研讨|视频观看|破冰游戏)", fw)
        if bad:
            add(ERROR, "内容框架·活动名", "框架中出现教学活动名称：%s" % "、".join(sorted(set(bad))))

    # ---------- 3. 字数 ----------
    bg = region(text, r"（一）课程开发背景|\(一\)课程开发背景", [r"（二）课程目标|\(二\)课程目标"])
    paras = [p.strip() for p in re.split(r"\n\s*\n|\n", bg) if p.strip() and not p.strip().startswith(("#", ">", "|"))]
    paras = [p for p in paras if cn_len(p) > 20]
    if paras:
        lens = [cn_len(p) for p in paras]
        detail = "各段字数：%s（参考 120/140/140）" % " / ".join(str(x) for x in lens)
        if len(paras) != 3:
            add(WARN, "背景·段数", "%d 段（要求三段式）｜%s" % (len(paras), detail))
        elif max(abs(lens[0] - 120), abs(lens[1] - 140), abs(lens[2] - 140)) > 45:
            add(WARN, "背景·字数", detail)
        else:
            add(OK, "背景·字数", detail)

    obj = region(text, r"（三）培训对象|\(三\)培训对象", [r"（四）课程时长|\(四\)课程时长"])
    pl = [p for p in obj.split("\n") if cn_len(p.strip()) > 40 and not p.strip().startswith(("#", "本部分", ">"))]
    if pl:
        n = cn_len(pl[0])
        if not (100 <= n <= 160):
            add(WARN, "培训对象·字数", "%d 字（要求 100-160）" % n)
        else:
            add(OK, "培训对象·字数", "%d 字" % n)
    if "不面向" not in obj and "排除" not in obj:
        add(WARN, "培训对象·排除对象", "未写“本课程不面向……”，教学起点一致性缺一句")

    # ---------- 4/5. 目标 ----------
    goal = region(text, r"（二）课程目标|\(二\)课程目标", [r"（三）培训对象|\(三\)培训对象"])
    for key in ("知识目标", "技能目标", "态度目标"):
        seg = [l for l in goal.splitlines() if key in l]
        if not seg:
            add(WARN, "目标·缺失", "未找到%s" % key)
            continue
        if "学员能够" not in seg[0] and "学员能够" not in (seg[1] if len(seg) > 1 else ""):
            add(ERROR, "目标·句式", "%s 未以“学员能够”开头" % key)
    banned = [w for w in ("掌握", "精通", "深入了解") if w in goal]
    if banned:
        add(ERROR, "目标·禁用词", "出现不可观察动词：%s" % "、".join(banned))

    sk = "\n".join(l for l in goal.splitlines() if "技能目标" in l)
    if sk:
        has_cond = any(w in sk for w in ("依据", "对照", "根据", "按照"))
        has_std = any(w in sk for w in ("做到", "均符合", "均达到", "标准"))
        if not (has_cond and has_std):
            add(WARN, "目标·ABCD", "技能目标缺%s（A对象/B行为必备，C条件、D标准需写全）"
                % ("＋".join([x for x, ok in (("条件", has_cond), ("标准", has_std)) if not ok])))
        else:
            add(OK, "目标·ABCD", "条件与标准均已写明")

    skill_kw = re.sub(r"[^\u4e00-\u9fa5]", "", sk)
    if skill_kw and sk and skill_kw not in re.sub(r"[^\u4e00-\u9fa5]", "", text.split("技能目标")[0] + " ".join(paras)):
        pass  # 闭环检查需语义判断，交由人工清单

    # ---------- 7. 内容要点里的动作 ----------
    bad_keys = re.findall(r"(讲师讲解|教师讲解|学员讨论|教师演示|讲师示范了)", text)
    if bad_keys:
        add(WARN, "内容要点·动作混入", "出现含主语的讲解/讨论表述（%d 处），请确认是否写在“内容要点”列：%s"
            % (len(bad_keys), "、".join(sorted(set(bad_keys)))))

    # ---------- 8. 四字动宾 ----------
    phrases = []
    for blk in re.split(r"教学活动组织[：:]", text)[1:]:
        blk = re.split(r"\n\s*\|?\s*(?:\*{0,2}环节|\d+\.(?:课程导入|模块|综合练习|练习与反馈|总结))", blk)[0]
        blk = blk.split("\n\n")[0]
        for m in re.finditer(r"(\d{1,2})[.、](?!\d)\s*([^\n：:；;|]{2,10})[：:]", blk):
            phrases.append((m.group(1), m.group(2).strip()))
    if phrases:
        bad = [(i, p) for i, p in phrases if len(re.sub(r"[^\u4e00-\u9fa5]", "", p)) != 4]
        if bad:
            add(WARN, "活动组织·短语", "%d/%d 条起句不是四字动宾：%s"
                % (len(bad), len(phrases), "、".join("%s.%s" % (i, p) for i, p in bad[:8])))
        else:
            add(OK, "活动组织·短语", "%d 条起句均为四字动宾" % len(phrases))
    else:
        add(WARN, "活动组织·短语", "未解析到“1.××××：”形式的分点，请确认已按 1.2.3. 分点")

    # ---------- 输出 ----------
    icons = {ERROR: "[×]", WARN: "[!]", OK: "[√]"}
    order = {ERROR: 0, WARN: 1, OK: 2}
    print("=" * 66)
    print("讲师手册自检报告  文件：%s" % sys.argv[1])
    print("=" * 66)
    for level, item, detail in sorted(issues, key=lambda x: order[x[0]]):
        print("%s %-14s %s" % (icons[level], item, detail))
    errs = sum(1 for l, _, _ in issues if l == ERROR)
    warns = sum(1 for l, _, _ in issues if l == WARN)
    print("-" * 66)
    print("Error %d 项，Warning %d 项。" % (errs, warns))
    if errs or warns:
        print("以上为量化项提示，语义闭环（对象=落点岗位=目标A、重难点=教学过程对应环节）请按清单人工核。")
    return 1 if errs else 0


if __name__ == "__main__":
    sys.exit(main())
