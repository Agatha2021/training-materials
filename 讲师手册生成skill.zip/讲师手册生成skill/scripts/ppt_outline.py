# -*- coding: utf-8 -*-
"""
课件页清单：把 pptx 拆成“页码—标题—要点—页型”，供编写手册与核对页码使用。
用法：
    python -X utf8 ppt_outline.py 课件.pptx [--json 输出.json]

只用标准库（zipfile+xml），不依赖 python-pptx。
页型判定：cover 封面／overview 课程概要／transition 过渡页／practice 练习页／
        summary 总结页／content 内容页
"""
import json
import re
import sys
import zipfile
from xml.etree import ElementTree as ET

A = '{http://schemas.openxmlformats.org/drawingml/2006/main}'
CN_NUM = '一二三四五六七八九十'


def slide_texts(z, name):
    root = ET.fromstring(z.read(name))
    out = []
    for p in root.iter(A + 'p'):
        s = ''.join(t.text or '' for t in p.iter(A + 't')).strip()
        if s:
            out.append(s)
    return out


def classify(page, lines):
    blob = ' '.join(lines)
    if page == 1:
        return 'cover'
    if '课程概要' in blob:
        return 'overview'
    if '练习题' in blob or blob.startswith('练习'):
        return 'practice'
    if '课程总结' in blob or '总结' in blob:
        return 'summary'
    # 过渡页：整页只有模块名或"第X步 + 小标题"，不超过两行
    if len(lines) <= 2 and re.match(r'^(第[%s]步|[一二三][看查测])' % CN_NUM,
                                   lines[0] if lines else ''):
        return 'transition'
    return 'content'


def outline(path):
    z = zipfile.ZipFile(path)
    names = [n for n in z.namelist() if re.match(r'ppt/slides/slide\d+\.xml$', n)]
    names.sort(key=lambda n: int(re.findall(r'\d+', n)[0]))
    pages = []
    for i, n in enumerate(names, start=1):
        lines = slide_texts(z, n)
        pages.append({
            'page': i,
            'kind': classify(i, lines),
            'title': lines[0] if lines else '',
            'lines': lines,
        })
    if pages:
        pages[-1]['kind'] = 'closing'
    return pages


KIND_CN = {'cover': '封面', 'overview': '课程概要', 'transition': '过渡页',
           'practice': '练习页', 'summary': '总结页', 'closing': '结语页', 'content': '内容页'}


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    path = sys.argv[1]
    pages = outline(path)
    for p in pages:
        print('%2d  [%s] %s' % (p['page'], KIND_CN[p['kind']], p['title'][:40]))
    print('共 %d 页' % len(pages))
    if '--json' in sys.argv:
        idx = sys.argv.index('--json')
        out = sys.argv[idx + 1] if len(sys.argv) > idx + 1 else path + '.outline.json'
        with open(out, 'w', encoding='utf-8') as f:
            json.dump(pages, f, ensure_ascii=False, indent=1)
        print('saved:', out)


if __name__ == '__main__':
    main()
